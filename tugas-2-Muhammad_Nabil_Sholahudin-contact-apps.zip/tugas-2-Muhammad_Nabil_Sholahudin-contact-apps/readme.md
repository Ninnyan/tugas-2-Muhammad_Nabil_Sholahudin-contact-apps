
# Cara menjalankan program :

* pastikan sudah terinstal nodejs, untuk mengeceknya silahkan buka cmd dan ketik : 
```bash
node -v
```
jika muncul seperti ini : v18.12.1 berarti teman - teman sudah menginstall nodejs

* silahkan clone atau download kode ini kedalam komputer teman - teman 
* jika sudah, jalankan program tersebut dengan mengetik : 
```bash
node index.js
```
atau

```bash
npm run start
```
boleh pilih salah satu