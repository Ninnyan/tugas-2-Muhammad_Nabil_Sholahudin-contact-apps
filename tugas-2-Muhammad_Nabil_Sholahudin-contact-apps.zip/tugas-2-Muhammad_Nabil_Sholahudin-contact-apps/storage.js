const databaseKontak = []

module.exports = databaseKontak