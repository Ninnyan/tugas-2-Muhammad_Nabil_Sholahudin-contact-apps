// panggil fungsi readline 
const readline = require('./readline');
//  panggil fungsi untuk menyimpan database sementara
const databaseKontak = require('./storage');
const colors = require('./node_modules/colors')
colors.enable()

// buat object kosong untuk menampung inputan 
let objectKontak = {
    nama : '',
    nomorHp : ''
}


function viewMenu() { //fungsi untuk menampilkan halaman menu
    console.log("Selamat Datang Di Aplikasi Kontak !\n".america);
    console.log("====================================\n".rainbow.bold);
    console.log("Main Menu :\n".blue);
    console.log("1.Tambah Data \n".cyan);
    console.log("2.Lihat Data \n".yellow);
    console.log("3.Reset Data \n".magenta);
    console.log("4.Pencarian Data \n".green);
    console.log("5.Hapus Data \n".blue);
    console.log("99.EXIT \n".white);
    readline.question(`Silahkan Masukan Pilihan Anda  :`.america, input => {
        mainMenu(Number(input))
    });
}



function mainMenu(pilihan) { // fungsi untuk mengatur pilihan menu
    switch (pilihan) {
        case 1:
            simpan()
            break;
        case 2:
            lihatData() 
            break;
        // lanjutkan menu pilihanya disini secara urut
        case 3:
            resetData()
            break;
        case 4:
            pencarianData()
            break;
        case 5:
            hapusData()
            break;
        case 99:
            console.log("Terima Kasih, Semoga Hari Mu Menyenangkan !".rainbow);
            readline.close()
            break;
        default:
            console.log("Input Tidak Valid".red);
            kembali()
        }
    }
        
        
        
        function simpan() { // fungsi untuk menyimpan data
            console.log("Silahkan Masukan Data ! : ".blue);
            readline.question("Nama :".cyan, (nama) => {
                if (isNaN(nama)) {
                    objectKontak.nama = nama
                    console.log(`Input data berhasil ! :${nama}`.america);
            ambilInputanNomor()
        } else {
            console.error(`EROR>> HARUS BERUPA HURUF`.red);
        }
        kembali()
    })
    
}
const ambilInputanNomor = () => { // fungsi untuk mengambil inputan nomor
    readline.question("Nomor :".cyan, (nomor) => {
        if (Number(nomor)) {
            objectKontak.nomorHp = nomor
            databaseKontak.push(Object.assign({},objectKontak)) // insert data kedalam array databseKOntak
            
        } else {
            console.error(`EROR>> HARUS BERUPA ANGKA`.red);
        }
        kembali()
        
    })
}
const kembali = () => { // fungsi untuk navigasi kembali
    readline.question("Apakah Anda Ingin Kembali ? (y/n) :".america, (pilihan) => {
        if(pilihan === "y"){
            viewMenu()
        }else {
            console.log("Terima Kasih, Semoga Hari Mu Menyenangkan !".rainbow);
            readline.close()
        }
        
    })
}

function lihatData () { // fungsi untuk melihat list data
    console.table(databaseKontak);
    kembali()
}

function resetData () {
    // tambahkan fungsi reset  data disini
    console.table(databaseKontak);
    readline.question(`Anda Ingin Mereset Data (y/n) :`.america, (pilihNomer)=> {
        if (pilihNomer === "y") {
            databaseKontak.splice(0)
            console.log(`Data Berhasil di Reset`.blue);
        } else {
            kembali()
        }
        kembali()

    })
    
}
function pencarianData () {
    // tambahkan fungsi pencarian data disini 
   readline.question(`Masukan Nama Yang Dicari :`.america, (cariNama) => {
    let cariData = databaseKontak.filter(function(data) {
        return data.nama.toLowerCase().includes(cariNama)
    })
    if (cariData.length === 0) {
        console.log(`Kontak tidak Ditemukan`.red);
    }else {
        console.log(`Hasil Pencarian`.magenta);
        for (let i = 0;i < cariData.length;i++) {
            console.table(cariData[i]);
        }
    } 
    
    kembali()
   })
}

function hapusData () {
    // tambahkan fungsi hapus data data disini 
    console.table(databaseKontak);
    readline.question(`Masukan Nomor Data yang akan dihapus (Dimulai 0) :`.america, (dataDihapus) => {
        if (Number(dataDihapus) === 0 && dataDihapus < databaseKontak.length) {
            databaseKontak.splice(dataDihapus,1)
            console.log(`Data Terbaru`.blue);
            console.table(databaseKontak);
        } else if (Number(dataDihapus) && dataDihapus < databaseKontak.length) {
            databaseKontak.splice(dataDihapus,1)
            console.log(`Data Terbaru`.blue);
            console.table(databaseKontak);

        } else{
            console.error(`EROR>>> INPUT TIDAK VALID`.red);
         }
       
        
        kembali()
    })
   
}
    
    
  



viewMenu() // panggil fungsi view menu untuk pertama kali